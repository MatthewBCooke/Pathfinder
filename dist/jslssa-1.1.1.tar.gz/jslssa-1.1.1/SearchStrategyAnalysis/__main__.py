#!/usr/bin/env python

"""searchStrategyAnalysis.py: GUI + analyses ethovision exported xlsx files to determine which search strategy animals follow during
Morris Water Maze trials."""

from __future__ import print_function
import threading
import csv
import webbrowser
from xlrd import open_workbook
import os
import fnmatch
import math
import sys
import logging
from time import localtime, strftime
import time
import plotly.plotly as py
import numpy as np
import multiprocessing
from multiprocessing import Queue
import PIL.Image
from PIL import ImageTk
from sys import platform as _platform
if sys.version_info<(3,0,0):  # tkinter names for python 2
    print("Update to Python3 for best results... You may encounter errors")
    from Tkinter import *
    import tkMessageBox as messagebox
    import ttk
    import tkFileDialog as filedialog
else:  # tkinter for python 3
    from tkinter import *
    from tkinter import messagebox
    from tkinter import ttk
    from tkinter import filedialog
if _platform == "darwin":
    import matplotlib
    matplotlib.use('TkAgg')  # prevent bugs on Mac
import matplotlib.pyplot as plt


__author__ = "Matthew Cooke"
__copyright__ = "Copyright 2017, Jason Snyder Lab, The University of British Columbia"
__credits__ = ["Matthew Cooke", "Tim O'Leary"]
__email__ = "matthew.cooke@alumni.ubc.ca"

logfilename = "logfile " + str(strftime("%Y_%m_%d %I_%M_%S_%p", localtime())) + ".log"  # name of the log file for the run
logging.basicConfig(filename=logfilename,level=logging.DEBUG)  # set the default log type to INFO, can be set to DEBUG for more detailed information
csvfilename = "results " + str(
    strftime("%Y_%m_%d %I_%M_%S_%p", localtime())) + ".csv"  # name of the default results file
theFile = ""
excelFileDirectory = ""
platformPosVar = "Auto"  # -21,31
poolDiamVar = "Auto"  # 180.0
corridorWidthVar = "35"
poolCentreVar = "Auto"  # 14.43,-4.409
oldPlatformPosVar = ""
chainingRadiusVar = "50.0"
thigmotaxisZoneSizeVar = "20"
outputFile = csvfilename
fileFlag = 0

jslsMaxVal = 1200
headingMaxVal = 25
distanceToSwimMaxVal = 0.45
distanceToPlatMaxVal = 0.5
corridorAverageMaxVal = 0.7
corridorjslsMaxVal = 5000
annulusCounterMaxVal = 0.85
quadrantTotalMaxVal = 3
percentTraversedMaxVal = 60
percentTraversedMinVal = 10
distanceToCentreMaxVal = 0.7
innerWallMaxVal = 0.5
outerWallMaxVal = 0.3
jslsIndirectMaxVal = 1500
percentTraversedRandomMaxVal = 30

isRuediger = False
customFlag = False
useDirectSwimV = True
useFocalSearchV = True
useDirectedSearchV = True
useScanningV = True
useChainingV = True
useRandomV = True
useIndirectV = True
useThigmoV = True
usePerseveranceV = False

root = Tk()  # set up the root
theStatus = StringVar()  # create the status bar text
theStatus.set('Waiting for user input...')  # set status bar text
platformPosStringVar = StringVar()  # setup all the gui variables (different from normal variables)
platformPosStringVar.set(platformPosVar)
poolDiamStringVar = StringVar()
poolDiamStringVar.set(poolDiamVar)
corridorWidthStringVar = StringVar()
corridorWidthStringVar.set(corridorWidthVar)
poolCentreStringVar = StringVar()
poolCentreStringVar.set(poolCentreVar)
oldPlatformPosStringVar = StringVar()
oldPlatformPosStringVar.set(oldPlatformPosVar)
chainingRadiusStringVar = StringVar()
chainingRadiusStringVar.set(chainingRadiusVar)
thigmotaxisZoneSizeStringVar = StringVar()
thigmotaxisZoneSizeStringVar.set(thigmotaxisZoneSizeVar)
outputFileStringVar = StringVar()
outputFileStringVar.set(outputFile)
useManual = BooleanVar()
useManual.set(False)

def show_error(text):  # popup box with error text
    logging.debug("Displaying Error")
    try:
        top = Toplevel(root)  # show as toplevel
        Label(top, text=text).pack()   # label set to text
        Button(top, text="OK", command=top.destroy).pack(pady=5)   # add ok button
    except:
        logging.info("Couldn't Display error "+text)

class Trial(object):  # an object for our row values
    def __init__(self, time, x, y):
        self.time = time
        self.x = x
        self.y = y

    def __str__(self):
        return("Trial object:\n"
               "  Time = {0}\n"
               "  x = {1}\n"
               "  y = {2}"
               .format(self.time, self.x, self.y))

class csvDisplay:
    def __init__(self, root):
        global canvas
        global xscrollbar
        global vsb
        global frame
        try:  # we try to delete a canvas (if one exists this will execute)
            deleteCanvas()
            logging.info("Canvas destroyed")
        except:
            logging.debug("Didn't kill canvas, could be first call")

        logging.debug("CSV Display is called")

        try:
            canvas = Canvas(root, borderwidth=0, width=500, height=400, bg="white")  # we create the canvas
            frame = Frame(canvas)   # we place a frame in the canvas
            xscrollbar = Scrollbar(root, orient=HORIZONTAL, command=canvas.xview)   # we add a horizontal scroll bar
            xscrollbar.pack(side=BOTTOM, fill=X)   # we put the horizontal scroll bar on the bottom
            vsb = Scrollbar(root, orient="vertical", command=canvas.yview)   # vertical scroll bar
            vsb.pack(side="right", fill="y")  # put on right

            canvas.pack(side="left", fill="both", expand=True)   # we pack in the canvas
            canvas.create_window((4, 4), window=frame, anchor="nw")   # we create the window for the results

            canvas.configure(yscrollcommand=vsb.set)   # we set the commands for the scroll bars
            canvas.configure(xscrollcommand=xscrollbar.set)
            frame.bind("<Configure>", lambda event, canvas=canvas: self.onFrameConfigure(canvas))   # we bind on frame configure
        except:
            logging.critical("Couldn't create the CSV canvas")

        try:   # we try and fill the canvas
            self.populate(frame)
        except Exception:   # if we can't fill
            logging.critical("Fatal error in populate")


    def populate(self, frame):  # function to populate the canvas
        logging.debug("Populating the CSV canvas")
        with open(outputFile, newline="") as file:   # we open the file with the results
            reader = csv.reader(file)   # read the file
            # r and c tell us where to grid the labels
            r = 0
            for col in reader:
                c = 0
                for row in col:   # for all columns and rows we place a label
                    # i've added some styling
                    label = Label(frame, width=20, height=1, \
                                          text=row, relief=RIDGE)
                    label.grid(row=r, column=c)
                    c += 1
                r += 1

    def onFrameConfigure(self, canvas):  # configure the frame
        canvas.configure(scrollregion=canvas.bbox("all"))

class mainClass:
    def __init__(self, root):  # init is called on runtime
        logging.debug("Initiating Main program")
        try:
            self.buildGUI(root)
        except:
            logging.fatal("Couldn't build GUI")
            self.tryQuit()
            return
        logging.debug("GUI is built")

    def buildGUI(self, root):  # Called in the __init__ to build the GUI window
        root.wm_title("Search Strategy Analysis")

        global platformPosVar
        global poolDiamVar
        global corridorWidthVar
        global poolCentreVar
        global oldPlatformPosVar
        global chainingRadiusVar
        global thigmotaxisZoneSizeVar
        global outputFile
        global manualFlag

        if _platform == "darwin":
            accelF = "CMD+F"
            accelD = "CMD+D"
            accelX = "CMD+X"
            accelC = "CMD+C"
            accelV = "CMD+V"
        else:
            accelF = "Ctrl+F"
            accelD = "Ctrl+D"
            accelX = "Ctrl+X"
            accelC = "Ctrl+C"
            accelV = "Ctrl+V"

        menu = Menu(root)  # create a menu
        root.config(menu=menu, bg="white")  # set up the config
        fileMenu = Menu(menu, tearoff=False, bg="white", fg="black")  # create file menu
        menu.add_cascade(label="File", menu=fileMenu)  # add cascading menus
        fileMenu.add_command(label="Open File...", accelerator=accelF,
                             command=self.openFile)  # add buttons in the menus
        fileMenu.add_command(label="Open Directory...", accelerator=accelD, command=self.openDir)
        fileMenu.add_separator()  # adds a seperator
        fileMenu.add_command(label="Exit", command=self.tryQuit)  # exit button quits

        editMenu = Menu(menu, tearoff=False, bg="white", fg="black")  # create edit menu
        menu.add_cascade(label="Edit", menu=editMenu)
        editMenu.add_command(label="Cut", \
                             accelerator=accelX, \
                             command=lambda: \
                                 root.focus_get().event_generate('<<Cut>>'))
        editMenu.add_command(label="Copy", \
                             accelerator=accelC, \
                             command=lambda: \
                                 root.focus_get().event_generate('<<Copy>>'))
        editMenu.add_command(label="Paste", \
                             accelerator=accelV, \
                             command=lambda: \
                                 root.focus_get().event_generate('<<Paste>>'))

        windowMenu = Menu(menu, tearoff=False, bg="white", fg="black")  # create window menu
        menu.add_cascade(label="Window", menu=windowMenu)
        windowMenu.add_command(label="Maximize", command=self.maximize)
        windowMenu.add_command(label="Minimize", command=self.minimize)

        helpMenu = Menu(menu, tearoff=False, bg="white", fg="black")  # create help menu
        menu.add_cascade(label="Help", menu=helpMenu)
        helpMenu.add_command(label="Help", command=self.getHelp)
        helpMenu.add_command(label="About", command=self.about)

        # ****** TOOLBAR ******
        toolbar = Frame(root)  # add a toolbar to the frame
        toolbar.config(bg="white")

        ttk.Style().configure('selected.TButton', foreground='red', background='white')  # have two button styles
        ttk.Style().configure('default.TButton', foreground='black',
                              background='white')  # note: we are using TKK buttons not tk buttons because tk buttons don't support style changes on mac

        self.snyderButton = ttk.Button(toolbar, text="Snyder et al., 2017", command=self.snyder,
                                       style='selected.TButton')  # add snyder button
        self.snyderButton.grid(row=0, ipadx=2, pady=2, padx=2)
        self.ruedigerButton = ttk.Button(toolbar, text="Ruediger et al., 2012", command=self.ruediger,
                                         style='default.TButton')  # add reudiger button
        self.ruedigerButton.grid(row=0, column=1, ipadx=2, pady=2, padx=2)
        self.gartheButton = ttk.Button(toolbar, text="Garthe et al., 2009", command=self.garthe,
                                       style='default.TButton')  # add garthe button
        self.gartheButton.grid(row=0, column=2, ipadx=2, pady=2, padx=2)
        self.customButton = ttk.Button(toolbar, text="Custom...", command=self.custom, style='default.TButton')
        self.customButton.grid(row=0, column=3, ipadx=2, pady=2, padx=2)  # add custom button
        toolbar.pack(side=TOP, fill=X)  # place the toolbar

        # ******* STATUS BAR *******
        status = Label(root, textvariable=theStatus, bd=1, relief=SUNKEN, anchor=W, bg="white")  # setup the status bar
        status.pack(side=BOTTOM, anchor=W, fill=X)  # place the status bar

        # ****** PARAMETERS SIDE ******
        paramFrame = Frame(root, bd=1, bg="white")  # create a frame for the parameters
        paramFrame.pack(side=LEFT, fill=BOTH, padx=5, pady=5)  # place this on the left

        platformPos = Label(paramFrame, text="Platform Position (x,y):", bg="white")  # add different items (Position)
        platformPos.grid(row=0, column=0, sticky=E)  # place this in row 0 column 0
        platformPosE = Entry(paramFrame, textvariable=platformPosStringVar)  # add an entry text box
        platformPosE.grid(row=0, column=1)  # place this in row 0 column 1

        poolDiam = Label(paramFrame, text="Pool Diameter:", bg="white")
        poolDiam.grid(row=1, column=0, sticky=E)
        poolDiamE = Entry(paramFrame, textvariable=poolDiamStringVar)
        poolDiamE.grid(row=1, column=1)

        poolCentre = Label(paramFrame, text="Pool Centre (x,y):", bg="white")
        poolCentre.grid(row=2, column=0, sticky=E)
        poolCentreE = Entry(paramFrame, textvariable=poolCentreStringVar)
        poolCentreE.grid(row=2, column=1)

        oldPlatformPos = Label(paramFrame, text="Old Platform Position (x, y):", bg="white")
        oldPlatformPos.grid(row=3, column=0, sticky=E)
        oldPlatformPosE = Entry(paramFrame, textvariable=oldPlatformPosStringVar)
        oldPlatformPosE.grid(row=3, column=1)

        headingError = Label(paramFrame, text="Corridor Width:", bg="white")
        headingError.grid(row=4, column=0, sticky=E)
        headingErrorE = Entry(paramFrame, textvariable=corridorWidthStringVar)
        headingErrorE.grid(row=4, column=1)

        chainingRadius = Label(paramFrame, text="Chaining Radius:", bg="white")
        chainingRadius.grid(row=5, column=0, sticky=E)
        chainingRadiusE = Entry(paramFrame, textvariable=chainingRadiusStringVar)
        chainingRadiusE.grid(row=5, column=1)

        thigmotaxisZoneSize = Label(paramFrame, text="Thigmotaxis Zone Size:", bg="white")
        thigmotaxisZoneSize.grid(row=6, column=0, sticky=E)
        thigmotaxisZoneSizeE = Entry(paramFrame, textvariable=thigmotaxisZoneSizeStringVar)
        thigmotaxisZoneSizeE.grid(row=6, column=1)

        saveDirectory = Label(paramFrame, text="Output File (.csv):", bg="white")
        saveDirectory.grid(row=7, column=0, sticky=E)
        saveDirectoryE = Entry(paramFrame, textvariable=outputFileStringVar)
        saveDirectoryE.grid(row=7, column=1)

        global outputFile  # allow outputFile to be accessed from anywhere (not secure)
        outputFile = outputFileStringVar.get()  # get the value entered for the ouput file

        manualFlag = False  # a flag that lets us know if we want to use manual categorization

        manualTickL = Label(paramFrame, text="Manual Categorization: ", bg="white")  # label for the tickbox
        manualTickL.grid(row=15, column=0, sticky=E)  # placed here
        manualTickC = Checkbutton(paramFrame, variable=useManual, bg="white")  # the actual tickbox
        manualTickC.grid(row=15, column=1)

        manualFlag = useManual.get()  # get the value of the tickbox

        calculateButton = Button(paramFrame, text="Calculate", fg="black",
                                 command=self.manual)  # add a button that says calculate
        calculateButton.grid(row=16, column=0, columnspan=3)

        if _platform == "darwin":
            root.bind('<Command-d>', self.ctrlDir)
            root.bind('<Command-f>', self.ctrlFile)
        else:
            root.bind('<Control-d>', self.ctrlDir)
            root.bind('<Control-f>', self.ctrlFile)

        root.bind('<Shift-Return>', self.enterManual)

    def openFile(self):  # opens a dialog to get a single file
        logging.debug("Open File...")
        global theFile
        global excelFileDirectory
        global fileFlag
        fileFlag = 1
        excelFileDirectory = ""
        theFile = filedialog.askopenfilename(filetypes = (("Excel Files","*.xlsx;*.xls"),))  # look for xlsx and xls files

    def openDir(self):  # open dialog to get multiple files
        logging.debug("Open Dir...")
        global excelFileDirectory
        global theFile
        global fileFlag
        fileFlag = 0
        theFile = ""
        excelFileDirectory = filedialog.askdirectory(mustexist=TRUE)

    def maximize(self):  # maximize the window
        logging.debug("Window maximized")
        root.attributes('-fullscreen', True)

    def minimize(self):  # minimize the window
        logging.debug("Window minimized")
        root.attributes('-fullscreen', False)

    def about(self):  # go to README
        logging.debug("Called about")
        webbrowser.open('https://github.com/Norton50/JSL/blob/master/README.md')

    def getHelp(self):  # go to readme
        logging.debug("Called help")
        webbrowser.open('https://github.com/Norton50/JSL/blob/master/README.md')

    def tryQuit(self):  # tries to stop threads
        logging.debug("trying to quit")
        try:
            t1.join()
            t2.join()
            print("success")
        except:
            root.destroy()
            return

        root.destroy()

    def enterManual(self, event):  # called when shift enter is pressed in the GUI
        self.manual()

    def ctrlDir(self, event):  # called when CTRL D is pressed
        self.openDir()

    def ctrlFile(self, event):
        self.openFile()

    def select1(self, event):
        self.directRadio.select()

    def select2(self, event):
        self.focalRadio.select()

    def select3(self, event):
        self.directedRadio.select()

    def select4(self, event):
        self.spatialRadio.select()

    def select5(self, event):
        self.chainingRadio.select()

    def select6(self, event):
        self.scanningRadio.select()

    def select7(self, event):
        self.randomRadio.select()

    def select8(self, event):
        self.thigmoRadio.select()

    def select9(self, event):
        self.notRecognizedRadio.select()

    def enterSave(self, event):
        self.saveStrat()

    def manual(self):  # function that checks for the manual flag and runs the program
        global manualFlag
        manualFlag = useManual.get()
        if manualFlag:  # if we want manual we can't use threading
            self.mainCalculate()
        else:  # else start the threads
            self.mainThreader()

    def snyder(self):  # actions on button press (snyder button)
        logging.debug("Snyder selected")
        self.snyderButton.configure(style='selected.TButton')  # change the style of the selected
        self.gartheButton.configure(style='default.TButton')  # and non-selected buttons
        self.ruedigerButton.configure(style='default.TButton')
        self.customButton.configure(style='default.TButton')

        global jslsMaxVal
        global headingMaxVal
        global distanceToSwimMaxVal
        global distanceToPlatMaxVal
        global corridorAverageMaxVal
        global annulusCounterMaxVal
        global quadrantTotalMaxVal
        global corridorjslsMaxVal
        global percentTraversedMaxVal
        global percentTraversedMinVal
        global distanceToCentreMaxVal
        global innerWallMaxVal
        global outerWallMaxVal
        global jslsIndirectMaxVal
        global percentTraversedRandomMaxVal
        # values we need access to
        # what these values should be
        jslsMaxVal = 1200
        headingMaxVal = 25
        distanceToSwimMaxVal = 0.45
        distanceToPlatMaxVal = 0.5
        corridorAverageMaxVal = 0.7
        corridorjslsMaxVal = 5000
        annulusCounterMaxVal = 0.85
        quadrantTotalMaxVal = 3
        percentTraversedMaxVal = 60
        percentTraversedMinVal = 10
        distanceToCentreMaxVal = 0.7
        innerWallMaxVal = 0.5
        outerWallMaxVal = 0.3
        jslsIndirectMaxVal = 1500
        percentTraversedRandomMaxVal = 30

    def ruediger(self):  # see snyder
        logging.debug("Ruediger selected")
        self.snyderButton.configure(style='default.TButton')
        self.gartheButton.configure(style='default.TButton')
        self.ruedigerButton.configure(style='selected.TButton')
        self.customButton.configure(style='default.TButton')

        global jslsMaxVal
        global headingMaxVal
        global distanceToSwimMaxVal
        global distanceToPlatMaxVal
        global corridorAverageMaxVal
        global annulusCounterMaxVal
        global quadrantTotalMaxVal
        global corridorjslsMaxVal
        global percentTraversedMaxVal
        global percentTraversedMinVal
        global distanceToCentreMaxVal
        global innerWallMaxVal
        global outerWallMaxVal
        global jslsIndirectMaxVal
        global percentTraversedRandomMaxVal
        global isRuediger

        jslsMaxVal = 1400
        headingMaxVal = 35
        distanceToSwimMaxVal = 0.45
        distanceToPlatMaxVal = 0.5
        corridorAverageMaxVal = 0.8
        corridorjslsMaxVal = 999999999  # inf
        annulusCounterMaxVal = 0.65
        quadrantTotalMaxVal = 0
        percentTraversedMaxVal = 70
        percentTraversedMinVal = 15
        distanceToCentreMaxVal = 0.7
        innerWallMaxVal = 0.65
        outerWallMaxVal = 0.35
        jslsIndirectMaxVal = 0
        percentTraversedRandomMaxVal = 70
        isRuediger = True

    def garthe(self):  # see snyder
        logging.debug("Garthe selected")
        self.snyderButton.configure(style='default.TButton')
        self.gartheButton.configure(style='selected.TButton')
        self.ruedigerButton.configure(style='default.TButton')
        self.customButton.configure(style='default.TButton')


        global jslsMaxVal
        global headingMaxVal
        global distanceToSwimMaxVal
        global distanceToPlatMaxVal
        global corridorAverageMaxVal
        global annulusCounterMaxVal
        global quadrantTotalMaxVal
        global corridorjslsMaxVal
        global percentTraversedMaxVal
        global percentTraversedMinVal
        global distanceToCentreMaxVal
        global innerWallMaxVal
        global outerWallMaxVal
        global jslsIndirectMaxVal
        global percentTraversedRandomMaxVal

        jslsMaxVal = 300
        headingMaxVal = 20
        distanceToSwimMaxVal = 0.35
        distanceToPlatMaxVal = 0.3
        corridorAverageMaxVal = 0.8
        corridorjslsMaxVal = 999999999  # inf
        annulusCounterMaxVal = 0.8
        quadrantTotalMaxVal = 0
        percentTraversedMaxVal = 60
        percentTraversedMinVal = 10
        distanceToCentreMaxVal = 0.7
        innerWallMaxVal = 0.65
        outerWallMaxVal = 0.35
        jslsIndirectMaxVal = 0
        percentTraversedRandomMaxVal = 60

    def custom(self):
        logging.debug("Getting custom values")
        global jslsMaxVal
        global headingMaxVal
        global distanceToSwimMaxVal
        global distanceToPlatMaxVal
        global corridorAverageMaxVal
        global annulusCounterMaxVal
        global quadrantTotalMaxVal
        global corridorjslsMaxVal
        global percentTraversedMaxVal
        global percentTraversedMinVal
        global distanceToCentreMaxVal
        global innerWallMaxVal
        global outerWallMaxVal
        global jslsIndirectMaxVal
        global percentTraversedRandomMaxVal

        global useDirectSwimV
        global useFocalSearchV
        global useDirectedSearchV
        global useScanningV
        global useChainingV
        global useRandomV
        global useIndirectV
        global useThigmoV
        global usePerseveranceV

        self.useDirectSwim = BooleanVar()
        self.useFocalSearch = BooleanVar()
        self.useDirectedSearch = BooleanVar()
        self.useScanning = BooleanVar()
        self.useChaining = BooleanVar()
        self.useRandom = BooleanVar()
        self.useIndirect = BooleanVar()
        self.useThigmo = BooleanVar()
        self.usePerseverance = BooleanVar()

        self.useDirectSwim.set(True)
        self.useFocalSearch.set(True)
        self.useDirectedSearch.set(True)
        self.useScanning.set(True)
        self.useChaining.set(True)
        self.useRandom.set(True)
        self.useIndirect.set(True)
        self.useThigmo.set(True)
        self.usePerseverance.set(False)

        self.snyderButton.configure(style='default.TButton')
        self.gartheButton.configure(style='default.TButton')
        self.ruedigerButton.configure(style='default.TButton')
        self.customButton.configure(style='selected.TButton')

        jslsMaxVal = 1200
        headingMaxVal = 25
        distanceToSwimMaxVal = 0.45
        distanceToPlatMaxVal = 0.5
        corridorAverageMaxVal = 0.7
        corridorjslsMaxVal = 5000
        annulusCounterMaxVal = 0.85
        quadrantTotalMaxVal = 3
        percentTraversedMaxVal = 60
        percentTraversedMinVal = 10
        distanceToCentreMaxVal = 0.7
        innerWallMaxVal = 0.5
        outerWallMaxVal = 0.3
        jslsIndirectMaxVal = 1500
        percentTraversedRandomMaxVal = 30

        self.jslsMaxCustom = StringVar()
        self.headingErrorCustom = StringVar()
        self.distanceToSwimCustom = StringVar()
        self.distanceToPlatCustom = StringVar()
        self.corridorAverageCustom = StringVar()
        self.corridorJslsCustom = StringVar()
        self.annulusCustom = StringVar()
        self.quadrantTotalCustom = StringVar()
        self.percentTraversedCustom = StringVar()
        self.percentTraversedMinCustom = StringVar()
        self.distanceToCentreCustom = StringVar()
        self.innerWallCustom = StringVar()
        self.outerWallCustom = StringVar()
        self.jslsIndirectCustom = StringVar()
        self.percentTraversedRandomCustom = StringVar()

        self.jslsMaxCustom.set(jslsMaxVal)
        self.headingErrorCustom.set(headingMaxVal)
        self.distanceToSwimCustom.set(distanceToSwimMaxVal * 100)
        self.distanceToPlatCustom.set(distanceToPlatMaxVal * 100)
        self.corridorAverageCustom.set(corridorAverageMaxVal * 100)
        self.corridorJslsCustom.set(corridorjslsMaxVal)
        self.annulusCustom.set(annulusCounterMaxVal * 100)
        self.quadrantTotalCustom.set(quadrantTotalMaxVal)
        self.percentTraversedCustom.set(percentTraversedMaxVal)
        self.percentTraversedMinCustom.set(percentTraversedMinVal)
        self.distanceToCentreCustom.set(distanceToCentreMaxVal * 100)
        self.innerWallCustom.set(innerWallMaxVal * 100)
        self.outerWallCustom.set(outerWallMaxVal * 100)
        self.jslsIndirectCustom.set(jslsIndirectMaxVal)
        self.percentTraversedRandomCustom.set(percentTraversedRandomMaxVal)
        # all of the above is the same as in snyder, plus the creation of variables to hold values from the custom menu

        top = Toplevel(root)  # we set this to be the top
        top.configure(bg="white")
        Label(top, text="Custom Values", bg="white", fg="red").grid(row=0, column=0, columnspan=2)  # we title it



        useDirectSwimL = Label(top, text="Direct Swim: ", bg="white")  # we add a direct swim label
        useDirectSwimL.grid(row=1, column=0, sticky=E)  # stick it to row 1
        useDirectSwimC = Checkbutton(top, variable=self.useDirectSwim, bg="white")  # we add a direct swim checkbox
        useDirectSwimC.grid(row=1, column=1)  # put it beside the label

        jslsMaxCustomL = Label(top, text="JSLs [maximum]: ", bg="white")  # label for JSLs
        jslsMaxCustomL.grid(row=2, column=0, sticky=E)  # row 2
        jslsMaxCustomE = Entry(top, textvariable=self.jslsMaxCustom)  # entry field
        jslsMaxCustomE.grid(row=2, column=1)  # right beside

        headingErrorCustomL = Label(top, text="Heading degree error [maximum]: ", bg="white")
        headingErrorCustomL.grid(row=3, column=0, sticky=E)
        headingErrorCustomE = Entry(top, textvariable=self.headingErrorCustom)
        headingErrorCustomE.grid(row=3, column=1)


        useFocalSearchL = Label(top, text="Focal Search: ", bg="white")
        useFocalSearchL.grid(row=4, column=0, sticky=E)
        useFocalSearchC = Checkbutton(top, variable=self.useFocalSearch, bg="white")
        useFocalSearchC.grid(row=4, column=1)

        usePerseveranceL = Label(top, text="Perseverance: ", bg="white")
        usePerseveranceL.grid(row=5, column=0, sticky=E)
        usePerseveranceC = Checkbutton(top, variable=self.usePerseverance, bg="white")
        usePerseveranceC.grid(row=5, column=1)

        distanceToSwimCustomL = Label(top, text="Distance to swim path centroid [% of radius]: ", bg="white")
        distanceToSwimCustomL.grid(row=6, column=0, sticky=E)
        distanceToSwimCustomE = Entry(top, textvariable=self.distanceToSwimCustom)
        distanceToSwimCustomE.grid(row=6, column=1)

        distanceToPlatCustomL = Label(top, text="Distance to platform [% of radius]: ", bg="white")
        distanceToPlatCustomL.grid(row=7, column=0, sticky=E)
        distanceToPlatCustomL = Entry(top, textvariable=self.distanceToPlatCustom)
        distanceToPlatCustomL.grid(row=7, column=1)


        useDirectedSearchL = Label(top, text="Directed Search: ", bg="white")
        useDirectedSearchL.grid(row=8, column=0, sticky=E)
        useDirectedSearchC = Checkbutton(top, variable=self.useDirectedSearch, bg="white", onvalue=1)
        useDirectedSearchC.grid(row=8, column=1)

        corridorAverageCustomL = Label(top, text="Angular corridor minimum [% of time]: ", bg="white")
        corridorAverageCustomL.grid(row=9, column=0, sticky=E)
        corridorAverageCustomE = Entry(top, textvariable=self.corridorAverageCustom)
        corridorAverageCustomE.grid(row=9, column=1)

        corridorJslsCustomL = Label(top, text="JSLs [maximum]: ", bg="white")
        corridorJslsCustomL.grid(row=10, column=0, sticky=E)
        corridorJslsCustomE = Entry(top, textvariable=self.corridorJslsCustom)
        corridorJslsCustomE.grid(row=10, column=1)


        useIndirectL = Label(top, text="Spatial Indirect: ", bg="white")
        useIndirectL.grid(row=11, column=0, sticky=E)
        useIndirectC = Checkbutton(top, variable=self.useIndirect, bg="white")
        useIndirectC.grid(row=11, column=1)

        jslsIndirectCustomL = Label(top, text="JSLs [maximum]: ", bg="white")
        jslsIndirectCustomL.grid(row=12, column=0, sticky=E)
        jslsIndirectCustomE = Entry(top, textvariable=self.jslsIndirectCustom)
        jslsIndirectCustomE.grid(row=12, column=1)


        useChainingL = Label(top, text="Chaining: ", bg="white")
        useChainingL.grid(row=13, column=0, sticky=E)
        useChainingC = Checkbutton(top, variable=self.useChaining, bg="white")
        useChainingC.grid(row=13, column=1)

        annulusCustomL = Label(top, text="Time in annulus zone [% of time]: ", bg="white")
        annulusCustomL.grid(row=14, column=0, sticky=E)
        annulusCustomE = Entry(top, textvariable=self.annulusCustom)
        annulusCustomE.grid(row=14, column=1)

        quadrantTotalCustomL = Label(top, text="Quadrants visited [minimum]: ", bg="white")
        quadrantTotalCustomL.grid(row=15, column=0, sticky=E)
        quadrantTotalCustomE = Entry(top, textvariable=self.quadrantTotalCustom)
        quadrantTotalCustomE.grid(row=15, column=1)


        useScanningL = Label(top, text="Scanning: ", bg="white")
        useScanningL.grid(row=16, column=0, sticky=E)
        useScanningC = Checkbutton(top, variable=self.useScanning, bg="white")
        useScanningC.grid(row=16, column=1)

        percentTraversedCustomL = Label(top, text="Area traversed [maximum]: ", bg="white")
        percentTraversedCustomL.grid(row=17, column=0, sticky=E)
        percentTraversedCustomE = Entry(top, textvariable=self.percentTraversedCustom)
        percentTraversedCustomE.grid(row=17, column=1)

        percentTraversedMinCustomL = Label(top, text="Area traversed [minimum]: ", bg="white")
        percentTraversedMinCustomL.grid(row=18, column=0, sticky=E)
        percentTraversedMinCustomE = Entry(top, textvariable=self.percentTraversedMinCustom)
        percentTraversedMinCustomE.grid(row=18, column=1)

        distanceToCentreCustomL = Label(top, text="Average distance to center [% of radius]: ", bg="white")
        distanceToCentreCustomL.grid(row=19, column=0, sticky=E)
        distanceToCentreCustomE = Entry(top, textvariable=self.distanceToCentreCustom)
        distanceToCentreCustomE.grid(row=19, column=1)


        useThigmoL = Label(top, text="Thigmotaxis: ", bg="white")
        useThigmoL.grid(row=20, column=0, sticky=E)
        useThigmoC = Checkbutton(top, variable=self.useThigmo, bg="white")
        useThigmoC.grid(row=20, column=1)

        innerWallCustomL = Label(top, text="Inner wall zone [% of time]: ", bg="white")
        innerWallCustomL.grid(row=21, column=0, sticky=E)
        innerWallCustomE = Entry(top, textvariable=self.innerWallCustom)
        innerWallCustomE.grid(row=21, column=1)

        outerWallCustomL = Label(top, text="Outer wall zone [% of time]: ", bg="white")
        outerWallCustomL.grid(row=22, column=0, sticky=E)
        outerWallCustomE = Entry(top, textvariable=self.outerWallCustom, bg="white")
        outerWallCustomE.grid(row=22, column=1)


        useRandomL = Label(top, text="Random Search: ", bg="white")
        useRandomL.grid(row=23, column=0, sticky=E)
        useRandomC = Checkbutton(top, variable=self.useRandom, bg="white")
        useRandomC.grid(row=23, column=1)

        percentTraversedRandomCustomL = Label(top, text="Area traversed [minimum]: ", bg="white")
        percentTraversedRandomCustomL.grid(row=24, column=0, sticky=E)
        percentTraversedRandomCustomE = Entry(top, textvariable=self.percentTraversedRandomCustom)
        percentTraversedRandomCustomE.grid(row=24, column=1)

        # we save the values from the fields and scale them appropriately
        jslsMaxVal = float(self.jslsMaxCustom.get())
        headingMaxVal = float(self.headingErrorCustom.get())
        distanceToSwimMaxVal = float(self.distanceToSwimCustom.get())/100
        distanceToPlatMaxVal = float(self.distanceToPlatCustom.get())/100
        corridorAverageMaxVal = float(self.corridorAverageCustom.get())/100
        corridorjslsMaxVal = float(self.corridorJslsCustom.get())
        annulusCounterMaxVal = float(self.annulusCustom.get())/100
        quadrantTotalMaxVal = float(self.quadrantTotalCustom.get())
        percentTraversedMaxVal = float(self.percentTraversedCustom.get())
        percentTraversedMinVal = float(self.percentTraversedMinCustom.get())
        distanceToCentreMaxVal = float(self.distanceToCentreCustom.get())/100
        innerWallMaxVal = float(self.innerWallCustom.get())/100
        outerWallMaxVal = float(self.outerWallCustom.get())/100
        jslsIndirectMaxVal = float(self.jslsIndirectCustom.get())
        percentTraversedRandomMaxVal = float(self.percentTraversedRandomCustom.get())

        useDirectSwimV = self.useDirectSwim.get()
        useFocalSearchV = self.useFocalSearch.get()
        useDirectedSearchV = self.useDirectedSearch.get()
        useScanningV = self.useScanning.get()
        useChainingV = self.useChaining.get()
        useRandomV = self.useRandom.get()
        useIndirectV = self.useIndirect.get()
        useThigmoV = self.useThigmo.get()

        Button(top, text="Save", command=self.saveCuston).grid(row=25, column=0, columnspan=2)  # button to save

    def saveCuston(self):  # save the custom values
        logging.debug("Saving custom parameters")
        global jslsMaxVal
        global headingMaxVal
        global distanceToSwimMaxVal
        global distanceToPlatMaxVal
        global corridorAverageMaxVal
        global annulusCounterMaxVal
        global quadrantTotalMaxVal
        global corridorjslsMaxVal
        global percentTraversedMaxVal
        global percentTraversedMinVal
        global distanceToCentreMaxVal
        global innerWallMaxVal
        global outerWallMaxVal
        global jslsIndirectMaxVal
        global percentTraversedRandomMaxVal

        global useDirectSwim
        global useFocalSearch
        global useDirectedSearch
        global useScanning
        global useChaining
        global useRandom
        global useIndirect
        global useThigmo

        global useDirectSwimV
        global useFocalSearchV
        global useDirectedSearchV
        global useScanningV
        global useChainingV
        global useRandomV
        global useIndirectV
        global useThigmoV

        jslsMaxVal = float(self.jslsMaxCustom.get())
        headingMaxVal = float(self.headingErrorCustom.get())
        distanceToSwimMaxVal = float(self.distanceToSwimCustom.get())/100
        distanceToPlatMaxVal = float(self.distanceToPlatCustom.get())/100
        corridorAverageMaxVal = float(self.corridorAverageCustom.get())/100
        corridorjslsMaxVal = float(self.corridorJslsCustom.get())
        annulusCounterMaxVal = float(self.annulusCustom.get())/100
        quadrantTotalMaxVal = float(self.quadrantTotalCustom.get())
        percentTraversedMaxVal = float(self.percentTraversedCustom.get())
        percentTraversedMinVal = float(self.percentTraversedMinCustom.get())
        distanceToCentreMaxVal = float(self.distanceToCentreCustom.get())/100
        innerWallMaxVal = float(self.innerWallCustom.get())/100
        outerWallMaxVal = float(self.outerWallCustom.get())/100
        jslsIndirectMaxVal = float(self.jslsIndirectCustom.get())
        percentTraversedRandomMaxVal = float(self.percentTraversedRandomCustom.get())

        useDirectSwimV = self.useDirectSwim.get()
        useFocalSearchV = self.useFocalSearch.get()
        useDirectedSearchV = self.useDirectedSearch.get()
        useScanningV = self.useScanning.get()
        useChainingV = self.useChaining.get()
        useRandomV = self.useRandom.get()
        useIndirectV = self.useIndirect.get()
        useThigmoV = self.useThigmo.get()
        usePerseveranceV = self.usePerseverance.get()

    def mainThreader(self):  # start the threaded execution
        logging.debug("Threading")

        try:
            t1 = threading.Thread(target=self.mainCalculate)  # create a thread for the main function
            t1.start()  # start that thread
            logging.debug("Threading mainCalculate thread started")
        except Exception:
            logging.critical("Fatal error in mainCalculate")  # couldnt be started
        try:
            t2 = threading.Thread(target=self.progressBar)  # create a thread for the progressBar
            t2.start()  # start that thread
            logging.debug("Threading progressBar thread started")
        except Exception:
            logging.critical("Fatal error in progressBar")  # couldn't be started

    def progressBar(self):  # create a progressbar
        logging.debug("ProgressBar")
        try:
            self.progress = ttk.Progressbar(orient="vertical", length=200, mode="determinate")  # create the bar
            self.progress.pack(side=LEFT)  # pack it left
            self.progress.start()  # start the bar
        except:
            logging.info("Couldn't generate a progressBar")

    def find_files(self, directory, pattern):  # searches for our files in the directory
        logging.debug("Finding files in the directory")
        for root, dirs, files in os.walk(directory):
            for basename in files:
                if fnmatch.fnmatch(basename, pattern):
                    filename = os.path.join(root, basename)
                    yield filename

    def plotPoints(self, x, y, poolDiam, centreX, centreY, platX, platY, scalingFactor, name):  # function to graph the data for the not recognized trials


        plotName = name + "    " + str(strftime("%Y_%m_%d %I_%M_%S_%p", localtime()))  # the name will be Animal id followed by the date and time
        plt.scatter(x, y, s=30, c='r', alpha=1)  # we plot the XY position of animal
        plt.scatter(x[0],y[0], s=150, c='b', alpha=1, marker='^')  # we plot the start point
        plt.scatter(platX, platY, s=1000, c='black', alpha=0.2)  # we plot the platform
        plt.scatter(centreX, centreY, s=150, c='g', alpha=1, marker='s')  # we plot the centre
        plt.title(plotName)  # add the title
        plt.xlim(centreX-poolDiam/2-30, centreX+poolDiam/2+30)  # set the size to be the center + radius + 30
        plt.ylim(centreY-poolDiam/2-30, centreY+poolDiam/2+30)
        photoName = plotName + ".png"  # image name the same as plotname
        plt.savefig(photoName, dpi=100, figsize=(2,2))  # save the file
        plt.clf()  # clear the plot
        image = PIL.Image.open(photoName)  # open the saved image
        photo = ImageTk.PhotoImage(image)  # convert it to something the GUI can read
        global searchStrategyV
        global searchStrategyStringVar

        searchStrategyStringVar = StringVar()  # temporary variable for the selection of strategies
        searchStrategyStringVar.set("Not Recognized")

        self.top2 = Toplevel(root)  # create a new toplevel window
        self.top2.configure(bg="white")
        Label(self.top2, text=name, bg="black", fg="white", width=15).grid(row=0, column=0, columnspan = 7)  # add a title
        photoimg = Label(self.top2, image=photo)  # add the photo
        photoimg.image = photo  # keep a reference
        photoimg.grid(row=1, column=0, columnspan=7)  # place the photo in the window

        Label(self.top2, text="LEGEND: ", bg="black", fg="white", width=15).grid(row=2, column=0, padx=3)  # create the legend
        Label(self.top2, text="Start position", bg="blue", fg="white", width=15).grid(row=2, column=1, padx=3)
        Label(self.top2, text="Platform position", bg="black", fg="white", width=15).grid(row=2, column=2, padx=3)
        Label(self.top2, text="Pool centre", bg="green", fg="white", width=15).grid(row=2, column=3, padx=3)
        Label(self.top2, text="Path", bg="red", fg="white", width=15).grid(row=2, column=4, padx=3)

        self.directRadio = Radiobutton(self.top2, text="(1) Direct Swim", variable=searchStrategyStringVar, value="Direct swim (m)",
                    indicatoron=0, width=15, bg="white")
        self.directRadio.grid(row=3, column=0, columnspan = 7, pady=3)  # add the radiobuttons for selection

        self.focalRadio = Radiobutton(self.top2, text="(2) Focal Search", variable=searchStrategyStringVar, value="Focal Search (m)",
                    indicatoron=0, width=15, bg="white")
        self.focalRadio.grid(row=4, column=0, columnspan = 7, pady=3)
        self.directedRadio = Radiobutton(self.top2, text="(3) Directed Search", variable=searchStrategyStringVar,
                    value="Directed Search (m)", indicatoron=0, width=15, bg="white")
        self.directedRadio.grid(row=5, column=0, columnspan = 7, pady=3)
        self.spatialRadio = Radiobutton(self.top2, text="(4) Spatial Indirect", variable=searchStrategyStringVar,
                    value="Spatial Indirect (m)", indicatoron=0, width=15, bg="white")
        self.spatialRadio.grid(row=6, column=0, columnspan = 7, pady=3)
        self.chainingRadio = Radiobutton(self.top2, text="(5) Chaining", variable=searchStrategyStringVar, value="Chaining (m)",
                                         indicatoron=0, width=15, bg="white")
        self.chainingRadio.grid(row=7, column=0, columnspan = 7, pady=3)
        self.scanningRadio = Radiobutton(self.top2, text="(6) Scanning", variable=searchStrategyStringVar, value="Scanning (m)",
                    indicatoron=0, width=15, bg="white")
        self.scanningRadio.grid(row=8, column=0, columnspan = 7, pady=3)
        self.randomRadio = Radiobutton(self.top2, text="(7) Random Search", variable=searchStrategyStringVar, value="Random Search (m)",
                    indicatoron=0, width=15, bg="white")
        self.randomRadio.grid(row=9, column=0, columnspan = 7, pady=3)
        self.thigmoRadio = Radiobutton(self.top2, text="(8) Thigmotaxis", variable=searchStrategyStringVar, value="Thigmotaxis (m)",
                    indicatoron=0, width=15, bg="white")
        self.thigmoRadio.grid(row=10, column=0, columnspan=7, pady=3)
        self.notRecognizedRadio = Radiobutton(self.top2, text="(9) Not Recognized", variable=searchStrategyStringVar, value="Not Recognized (m)",
                    indicatoron=0, width=15, bg="white")
        self.notRecognizedRadio.grid(row=11, column=0, columnspan = 7, pady=3)

        if _platform == "darwin":
            ButtonMac(self.top2, text="(Return) Save", command=self.saveStrat, fg="black", bg="white", width=15).grid(row=12,
                                                                                                          column=0,
                                                                                                          columnspan=7,
                                                                                                          pady=5)
        else:
            Button(self.top2, text="Save", command=self.saveStrat, fg="white", bg="black", width=15).grid(row=12,
                                                                                                          column=0,
                                                                                                          columnspan=7,
                                                                                                          pady=5)  # save button not mac

        self.top2.bind('1', self.select1)
        self.top2.bind('2', self.select2)
        self.top2.bind('3', self.select3)
        self.top2.bind('4', self.select4)
        self.top2.bind('5', self.select5)
        self.top2.bind('6', self.select6)
        self.top2.bind('7', self.select7)
        self.top2.bind('8', self.select8)
        self.top2.bind('9', self.select9)



        self.top2.bind('<Return>', self.enterSave)

        self.top2.focus_force()  # once built, show the window in front

        searchStrategyV = searchStrategyStringVar.get()  # get the solution


        logging.info("Plotted " + plotName)

    def saveStrat(self):  # save the manual strategy
        global searchStrategyV
        global searchStrategyStringVar

        searchStrategyV = searchStrategyStringVar.get()  # get the value to be saved
        try:  # try and destroy the window
            self.top2.destroy()
        except:
            pass

    def updateTasks(self):  # called when we want to push an update to the GUI
        try:
            root.update_idletasks()
            root.update()  # update the gui
        except:
            logging.info("Couldn't update the GUI")

    def killBar(self):  # called when we want to kill the progressBar
        try:
            self.progress.stop()
            self.progress.destroy()
        except:
            logging.info("Couldn't destroy the progressBar")

    def mainCalculate(self):  # the main program
        logging.debug("Calculate called")
        self.updateTasks()

        global platformPosVar
        global poolDiamVar
        global poolCentreVar
        global oldPlatformPosVar
        global corridorWidthVar
        global chainingRadiusVar
        global thigmotaxisZoneSizeVar
        global outputFile
        global canvas
        global frame
        global vsb
        global xscrollbar
        global manualFlag
        global useManuel
        global searchStrategyV
        global poolCentreX
        global poolCentreY
        global platformX
        global platformY
        global poolRadius
        global centreFlag
        global platFlag
        global diamFlag
        global skipFlag


        outputFile = outputFileStringVar.get()  # get output file
        try:  # try to remove the csv display (for second run)
            theStatus.set('Removing CSV display...')
            self.updateTasks()
            canvas.destroy()
            frame.destroy()
            vsb.destroy()
            xscrollbar.destroy()
            logging.info("CSV display destroyed")
        except:
            logging.debug("Couldn't remove CSV display")

        platformPosVar = platformPosStringVar.get()
        poolDiamVar = poolDiamStringVar.get()
        poolCentreVar = poolCentreStringVar.get()
        oldPlatformPosVar = oldPlatformPosStringVar.get()
        corridorWidthVar = corridorWidthStringVar.get()
        chainingRadiusVar = chainingRadiusStringVar.get()
        thigmotaxisZoneSizeVar = thigmotaxisZoneSizeStringVar.get()  # get important values

        # basic setup
        extensionType = r'*.xlsx'
        poolRadius = 0.0
        thigmotaxisZoneSize = 0.0
        corridorWidth = 0.0
        platformX = 0.0
        platformY = 0.0
        oldDay = ""
        oldPlatformX = platformX
        oldPlatformY = platformY

        chainingRadius = 0.0

        poolCenter = (0.0, 0.0)


        poolRadius = 0.0
        smallerWallZone = 0.0
        biggerWallZone = 0.0
        distanceCenterToPlatform = 0.0
        totalTrialCount = 0.0
        thigmotaxisCount = 0.0
        randomCount = 0.0
        scanningCount = 0.0
        chainingCount = 0.0
        directSearchCount = 0.0
        focalSearchCount = 0.0
        directSwimCount = 0.0
        perseveranceCount = 0.0
        spatialIndirectCount = 0.0
        notRecognizedCount = 0.0
        oldTotalCount = 0.0
        oldThigmotaxisCount = 0.0
        oldRandomCount = 0.0
        oldScanningCount = 0.0
        oldChainingCount = 0.0
        oldDirectSearchCount = 0.0
        oldFocalSearchCount = 0.0
        oldDirectSwimCount = 0.0
        oldPerseveranceCount = 0.0
        oldspatialIndirectCount = 0.0
        oldNotRecognizedCount = 0.0
        n = 0
        numOfRows = 0
        lastX = 0.0
        lastY = 0.0
        platEstX = 0.0
        platEstY = 0.0
        maxX = 0.0
        minX = 0.0
        maxY = 0.0
        minY = 0.0
        avMaxY = 0.0
        avMinY = 0.0
        avMaxX = 0.0
        avMinX = 0.0
        absMaxX = 0.0
        absMaxY = 0.0
        absMinX = 0.0
        absMinY = 0.0
        poolCentreEstX = 0.0
        poolCentreEstY = 0.0
        count = 0.0
        centreCount = 0.0
        flag = False
        dayFlag = False
        autoFlag = False
        skipFlag = False
        centreFlag = False
        platFlag = False
        diamFlag = False

        if platformPosVar != "Auto" and platformPosVar != "auto" and platformPosVar != "automatic" and platformPosVar != "Automatic" and platformPosVar != "":  # if we want manual platform
            platformX, platformY = platformPosVar.split(",")
            platformX = float(platformX)
            platformY = float(platformY)
            logging.debug("Platform position set manually: "+str(platformPosVar))
        elif fileFlag == 1:  # if we only chose 1 trial
            logging.error("Tried to get platform position from single trial")
            show_error("You must enter concrete position(s) for a single trial")
            self.killBar()
            return
        else:  # automatic platform calculation
            platFlag = True

        if poolCentreVar != "Auto" and poolCentreVar != "auto" and poolCentreVar != "automatic" and poolCentreVar != "Automatic" and poolCentreVar != "":  # manual pool center
            poolCentreX, poolCentreY = poolCentreVar.split(",")
            poolCentreX = float(poolCentreX)
            poolCentreY = float(poolCentreY)
            logging.debug("Pool centre set manually: "+str(poolCentreVar))
        elif fileFlag == 1:  # if we only chose 1 trial
            logging.error("Tried to get pool centre from single trial")
            show_error("You must enter concrete position(s) for a single trial")
            self.killBar()
            return
        else:  # automatic pool centre
            centreFlag = True

        if poolDiamVar != "Auto" and poolDiamVar != "auto" and poolDiamVar != "automatic" and poolDiamVar != "Automatic" and poolDiamVar != "":  # manual diameter
            poolRadius = float(poolDiamVar) / 2.0
            logging.debug("Pool diameter set manually: " + str(poolDiamVar))
        elif fileFlag == 1:  # if we only chose 1 trial
            logging.error("Tried to get diameter from single trial")
            show_error("You must enter concrete position(s) for a single trial")
            self.killBar()
            return
        else:  # automatic diameter
            diamFlag = True

        if platFlag == True or centreFlag == True or diamFlag == True:  # update the status bar depending on choice
            if platFlag == True and diamFlag == False:
                theStatus.set('Getting platform position...')
                logging.debug("Getting platform position")
                if centreFlag == True:
                    logging.debug("Getting platform and pool centre positions")
                    theStatus.set('Getting platform and pool centre positions...')
            elif platFlag == True and diamFlag == True:
                theStatus.set('Getting platform position and pool diameter...')
                logging.debug("Getting platform position and pool diameter")
                if centreFlag == True:
                    logging.debug("Getting platform and pool centre positions and pool diameter")
                    theStatus.set('Getting platform and pool centre positions and pool diameter...')
            elif centreFlag == True and diamFlag == True:
                logging.debug("Getting pool centre position and pool diameter")
                theStatus.set("Getting pool centre position and pool diameter")
            elif diamFlag == True and platFlag == False:
                theStatus.set('Getting pool diameter...')
                logging.debug("Getting pool diameter")
            else:
                logging.debug("Getting pool centre position")
                theStatus.set('Getting pool centre position...')

            self.updateTasks()
            for aFile in self.find_files(excelFileDirectory, extensionType):
                i = 0.0
                try:
                    wb = open_workbook(aFile)
                except:
                    logging.warning("File with corrupted data: " + aFile)
                    show_error("Corrupted Excel File " + aFile)
                    continue
                for sheet in wb.sheets():  # for all sheets in the workbook
                    number_of_rows = sheet.nrows
                    headerLines = int(sheet.cell(0, 1).value)  # gets number of header lines in the spreadsheet
                    numOfRows = sheet.nrows - headerLines
                    number_of_columns = sheet.ncols
                    fullTrial = []
                    rows = []
                    k = 0
                    for row in range(headerLines, number_of_rows):  # for each row

                        values = []

                        for col in range(1, 4):  # for columns 1 through 4, get all the values
                            value = sheet.cell(row, col).value
                            try:
                                value = float(value)
                            except ValueError:
                                pass
                            finally:
                                values.append(value)

                        item = Trial(*values)
                        fullTrial.append(item)

                    for item0 in fullTrial:  # for each row in our sheet
                        if item0.x == "-":  # throw out missing data
                            continue
                        if item0.y == "-":
                            continue
                        if item0.time < 1.0:
                            continue
                        if item0.time > (((number_of_rows - 39) * 0.04) - 1):
                            continue
                        if item0.time < 50.0:
                            lastX = item0.x
                            lastY = item0.y
                            skipFlag = False
                        else:
                            skipFlag = True

                        if item0.x > maxX:
                            maxX = item0.x
                        if item0.x < minX:
                            minX = item0.x
                        if item0.y > maxY:
                            maxY = item0.y
                        if item0.y < minY:
                            minY = item0.y

                    if maxX > absMaxX:
                        absMaxX = maxX
                    if minX < absMinX:
                        absMinX = minX
                    if maxY > absMaxY:
                        absMaxY = maxY
                    if minY < absMinY:
                        absMinY = minY

                    avMaxX += maxX
                    avMaxY += maxY
                    avMinX += minX
                    avMinY += minY
                    centreCount += 1.0

                    if skipFlag == False:
                        count += 1.0
                        platEstX += lastX
                        platEstY += lastY

            if centreCount < 1:  # we couldnt get the position
                if centreFlag:
                    logging.error("Unable to determine a centre position. Compatible trials: " + str(centreCount))
                    messagebox.showwarning('Centre Error',
                                           'Unable to determine a centre position. Compatible trials')
                elif centreFlag and diamFlag:
                    logging.error(
                        "Unable to determine a centre position and pool diameter. Compatible trials: " + str(
                            centreCount))
                    messagebox.showwarning('Centre and Diameter Error',
                                           'We were unable to determine a centre position or pool diameter from the trials')
                elif diamFlag:
                    logging.error("Unable to determine the pool diameter. Compatible trials: " + str(centreCount))
                    messagebox.showwarning('Diameter Error',
                                           'We were unable to determine a diameter from the trials')
                theStatus.set('Waiting for user input...')
                self.updateTasks()
                self.killBar()
                return

            if count < 1:
                logging.error("Unable to determine a platform posititon. Compatible trials: " + str(count))
                messagebox.showwarning('Platform Error',
                                       'We were unable to determine a platform position from the trials')
                theStatus.set('Waiting for user input...')
                self.updateTasks()
                self.killBar()
                return

            if centreFlag == True:  # if we want an automatic centre position
                avMaxX = avMaxX / centreCount  # get the average of the max X
                avMaxY = avMaxY / centreCount  # max Y
                avMinX = avMinX / centreCount  # min X
                avMinY = avMinY / centreCount  # min Y
                poolCentreEstX = (avMaxX + avMinX) / 2  # estmiate the centre
                poolCentreEstY = (avMaxY + avMinY) / 2
                poolCentreX = poolCentreEstX
                poolCentreY = poolCentreEstY
                logging.info("Automatic pool centre calculated as: " + str(poolCentreEstX) + ", " + str(poolCentreEstY))
            if platFlag == True:  # automatic platform
                platEstX = platEstX / count
                platEstY = platEstY / count
                platformX = platEstX
                platformY = platEstY
                logging.info("Automatic platform position calculated as: " + str(platEstX) + ", " + str(platEstY))
            if diamFlag == True:  # automatic diameter
                poolDiamEst = ((abs(absMaxX) + abs(absMinX)) + (abs(absMaxY) + abs(absMinY))) / 2
                logging.info("Automatic pool diameter calculated as: " + str(poolDiamEst))
                poolDiamVar = poolDiamEst
                poolRadius = float(poolDiamVar) / 2


        scalingFactor = float(poolDiamVar)/180.0  # set scaling factor for different pool sizes
        thigmotaxisZoneSize = float(thigmotaxisZoneSizeVar) * scalingFactor  # update the thigmotaxis zone
        chainingRadius = float(chainingRadiusVar) * scalingFactor  # update the chaining radius
        corridorWidth = int(corridorWidthVar) / 2  # update the corridor width

        smallerWallZone = poolRadius - math.ceil(thigmotaxisZoneSize / 2)  # update the smaller wall zone
        biggerWallZone = poolRadius - thigmotaxisZoneSize  # and bigger wall zone

        if excelFileDirectory == "":  # if we didnt select a directory
            if theFile == "":  # or a file
                messagebox.showwarning('No file or directory selected', 'Please select a directory or file under the File menu')
                self.killBar()
                logging.error("Unable to find trials")
                return  # stop


        theStatus.set('Calculating Search Strategies...')  # update status bar
        self.updateTasks()

        logging.debug("Calculating search strategies")

        try:  # try to open a csv file for output
            f = open(outputFile, 'wt')
            writer = csv.writer(f, delimiter=',', quotechar='"')
        except:
            logging.error("Cannot write to " + str(outputFile))
            self.killBar()
            return

        writer.writerow(
            ("Day", "Trial", "Trial ID", "Trial Name", "Strategy Type", "Animal ID", "Missing Data", "File"))  # write to the csv
        if fileFlag == 1:  # called when 1 file selected
            logging.debug("Single file selected")
            aFile = theFile
            i = 0.0
            try:
                wb = open_workbook(aFile)
            except:
                # print("Corrupted excel file", aFile)
                logging.error("Unable to open excel file" + aFile)
                try:
                    show_error("Corrupted Excel File " + aFile)
                except:
                    pass
                return


            for sheet in wb.sheets():  # for all sheets in the workbook
                number_of_rows = sheet.nrows
                headerLines = int(sheet.cell(0, 1).value)  # gets number of header lines in the spreadsheet
                numOfRows = sheet.nrows - headerLines
                number_of_columns = sheet.ncols
                fullTrial = []
                rows = []
                k = 0
                cCondition = ""
                cTreatment = ""
                cDay = ""
                cTemp = ""
                cGen = ""
                cAnimalID = ""
                cTrName = ""
                cTrID = ""
                cTr = ""

                for k in range(0, 39):  # GET CONDITION TREATMENT AND DAY VALUES
                    if str(sheet.cell(k, 0).value) == "Condition" or str(sheet.cell(k, 0).value) == "Restraint":
                        cCondition = str(sheet.cell(k, 1).value)
                    elif str(sheet.cell(k, 0).value) == "Treatment":
                        cTreatment = str(sheet.cell(k, 1).value)
                    elif str(sheet.cell(k, 0).value) == "Day":
                        cDay = str(sheet.cell(k, 1).value)
                    elif str(sheet.cell(k, 0).value) == "Temperature":
                        cTemp = str(sheet.cell(k, 1).value)
                    elif str(sheet.cell(k, 0).value) == "Genotype":
                        cGen = str(sheet.cell(k, 1).value)
                    elif str(sheet.cell(k, 0).value) == "Animal ID":
                        cAnimalID = str(sheet.cell(k, 1).value)
                    elif str(sheet.cell(k, 0).value) == "Trial name":
                        cTrName = str(sheet.cell(k, 1).value)
                    elif str(sheet.cell(k, 0).value) == "Trial ID":
                        cTrID = str(sheet.cell(k, 1).value)
                    elif str(sheet.cell(k, 0).value) == "Trial":
                        cTr = str(sheet.cell(k, 1).value)


                for row in range(headerLines, number_of_rows):  # for each row

                    values = []

                    for col in range(1, 4):  # for columns 1 through 4, get all the values
                        value = sheet.cell(row, col).value
                        try:
                            value = float(value)
                        except ValueError:
                            pass
                        finally:
                            values.append(value)

                    item = Trial(*values)
                    fullTrial.append(item)

            xSummed = 0.0
            ySummed = 0.0
            xAv = 0.0
            yAv = 0.0

            currentDistanceFromPlatform = 0.0
            distanceFromPlatformSummed = 0.0
            distanceAverage = 0.0
            aX = 0.0
            aY = 0.0

            missingData = 0

            distanceToCenterOfPool = 0.0
            totalDistanceToCenterOfPool = 0.0
            averageDistanceToCenter = 0.0

            innerWallCounter = 0.0
            outerWallCounter = 0.0
            annulusCounter = 0.0

            distanceToSwimPathCentroid = 0.0
            totalDistanceToSwimPathCentroid = 0.0
            averageDistanceToSwimPathCentroid = 0.0

            distanceToOldPlatform = 0.0
            totalDistanceToOldPlatform = 0.0
            averageDistanceToOldPlatform = 0.0

            jsls = 0.0

            startX = 0.0
            startY = 0.0

            areaCoverageGridSize = 18

            corridorCounter = 0.0
            quadrantOne = 0
            quadrantTwo = 0
            quadrantThree = 0
            quadrantFour = 0
            quadrantTotal = 0
            # </editor-fold>
            # initialize our cell matrix
            Matrix = [[0 for x in range(0, areaCoverageGridSize)] for y in range(0, areaCoverageGridSize)]
            # Analyze the data ----------------------------------------------------------------------------------------------
            for item in fullTrial:  # for each row in our sheet

                if item.x == "-":  # throw out missing data
                    missingData += 1  # keep track of how much we throw out
                    continue
                if item.y == "-":
                    missingData += 1
                    continue
                if item.time < 1.0:
                    continue
                if i == 0:
                    startX = item.x
                    startY = item.y
                if item.time > (((number_of_rows - 39) * 0.04) - 1):
                    continue
                # Swim Path centroid
                i += 1.0
                xSummed += float(item.x)
                ySummed += float(item.y)
                aX = float(item.x)
                aY = float(item.y)
                # Average Distance
                currentDistanceFromPlatform = math.sqrt((platformX - aX) ** 2 + (platformY - aY) ** 2)
                distanceFromPlatformSummed += currentDistanceFromPlatform
                distanceToOldPlatform = math.sqrt((oldPlatformX - aX) ** 2 + (oldPlatformY - aY) ** 2)
                totalDistanceToOldPlatform += distanceToOldPlatform

                # in zones
                poolCentreX, poolCentreY = poolCenter
                distanceCenterToPlatform = math.sqrt((poolCentreX - platformX) ** 2 + (poolCentreY - platformY) ** 2)
                annulusZoneInner = distanceCenterToPlatform - (chainingRadius / 2)
                annulusZoneOuter = distanceCenterToPlatform + (chainingRadius / 2)
                distanceToCenterOfPool = math.sqrt((poolCentreX - aX) ** 2 + (poolCentreY - aY) ** 2)
                totalDistanceToCenterOfPool += distanceToCenterOfPool
                distanceFromStartToPlatform = math.sqrt((platformX - startX) ** 2 + (platformY - startY) ** 2)

                jsls += -(distanceFromStartToPlatform - distanceFromPlatformSummed) / 1000

                if distanceToCenterOfPool > biggerWallZone:  # calculate if we are in zones
                    innerWallCounter += 1.0
                if distanceToCenterOfPool > smallerWallZone:
                    outerWallCounter += 1.0
                if (distanceToCenterOfPool >= annulusZoneInner) and (distanceToCenterOfPool <= annulusZoneOuter):
                    annulusCounter += 1

                a, b = 0, 0
                # grid creation
                # x values
                # <editor-fold desc="Grid">
                if item.x >= -100.0 and item.x <= -90:
                    a = -9
                elif item.x > -90 and item.x <= -80:
                    a = -8
                elif item.x > -80 and item.x <= -70:
                    a = -7
                elif item.x > -70 and item.x <= -60:
                    a = -6
                elif item.x > -60 and item.x <= -50:
                    a = -5
                elif item.x > -50 and item.x <= -40:
                    a = -4
                elif item.x > -40 and item.x <= -30:
                    a = -3
                elif item.x > -30 and item.x <= -20:
                    a = -2
                elif item.x > -20 and item.x <= -10:
                    a = -1
                elif item.x > -10 and item.x <= 0:
                    a = 0
                elif item.x > 0 and item.x <= 10:
                    a = 1
                elif item.x > 10 and item.x <= 20:
                    a = 2
                elif item.x > 20 and item.x <= 30:
                    a = 3
                elif item.x > 30 and item.x <= 40:
                    a = 4
                elif item.x > 40 and item.x <= 50:
                    a = 5
                elif item.x > 50 and item.x <= 60:
                    a = 6
                elif item.x > 60 and item.x <= 70:
                    a = 7
                elif item.x > 70 and item.x <= 80:
                    a = 8
                elif item.x > 80 and item.x <= 90:
                    a = 9

                # y value categorization
                if item.y >= -100.0 and item.y <= -90:
                    b = -9
                elif item.y > -90 and item.y <= -80:
                    b = -8
                elif item.y > -80 and item.y <= -70:
                    b = -7
                elif item.y > -70 and item.y <= -60:
                    b = -6
                elif item.y > -60 and item.y <= -50:
                    b = -5
                elif item.y > -50 and item.y <= -40:
                    b = -4
                elif item.y > -40 and item.y <= -30:
                    b = -3
                elif item.y > -30 and item.y <= -20:
                    b = -2
                elif item.y > -20 and item.y <= -10:
                    b = -1
                elif item.y > -10 and item.y <= 0:
                    b = 0
                elif item.y > 0 and item.y <= 10:
                    b = 1
                elif item.y > 10 and item.y <= 20:
                    b = 2
                elif item.y > 20 and item.y <= 30:
                    b = 3
                elif item.y > 30 and item.y <= 40:
                    b = 4
                elif item.y > 40 and item.y <= 50:
                    b = 5
                elif item.y > 50 and item.y <= 60:
                    b = 6
                elif item.y > 60 and item.y <= 70:
                    b = 7
                elif item.y > 70 and item.y <= 80:
                    b = 8
                elif item.y > 80 and item.y <= 90:
                    b = 9
                # </editor-fold>
                Matrix[a][b] = 1  # set matrix cells to 1 if we have visited them
                if (poolCentreX - aX) != 0:
                    centerArcTangent = math.degrees(math.atan((poolCentreY - aY) / (poolCentreX - aX)))

                # print centerArcTangent
                if item.x >= 0 and item.y >= 0:
                    quadrantOne = 1
                elif item.x < 0 and item.y >= 0:
                    quadrantTwo = 1
                elif item.x >= 0 and item.y < 0:
                    quadrantThree = 1
                elif item.x < 0 and item.y < 0:
                    quadrantFour = 1

            quadrantTotal = quadrantOne + quadrantTwo + quadrantThree + quadrantFour
            # <editor-fold desc="Swim Path centroid">
            if i <= 0:  # make sure we don't divide by 0
                i = 1

            xAv = xSummed / i  # get our average positions for the centroid
            yAv = ySummed / i
            swimPathCentroid = (xAv, yAv)

            aArcTangent = math.degrees(math.atan((platformY - startY) / (platformX - startX)))
            upperCorridor = aArcTangent + corridorWidth
            lowerCorridor = aArcTangent - corridorWidth
            corridorWidth = 0.0
            totalHeadingError = 0.0

            for item2 in fullTrial:  # go back through all values and calculate distance to the centroid
                if item2.x == "-":
                    continue
                if item2.y == "-":
                    continue
                if item2.time < 1.0:
                    continue
                distanceToSwimPathCentroid = math.sqrt((xAv - item2.x) ** 2 + (yAv - item2.y) ** 2)
                totalDistanceToSwimPathCentroid += distanceToSwimPathCentroid

                if (item2.x - startX) != 0 and i > 1 and (item2.x - oldItemX) > 0:
                    currentArcTangent = math.degrees(math.atan((item2.y - startY) / (item2.x - startX)))
                    corridorWidth = abs(
                        aArcTangent - abs(math.degrees(math.atan((item2.y - oldItemY) / (item2.x - oldItemX)))))
                else:
                    currentArcTangent = 0.0
                if float(lowerCorridor) <= float(currentArcTangent) <= float(upperCorridor):
                    corridorCounter += 1.0
                oldItemX = item2.x
                oldItemY = item2.y
                if item2.time < (((number_of_rows - 39) * 0.04) - 1):
                    totalHeadingError += corridorWidth
            # </editor-fold>
            # <editor-fold desc="Take Averages">
            corridorAverage = corridorCounter / i
            distanceAverage = distanceFromPlatformSummed / i  # calculate our average distances to landmarks
            averageDistanceToSwimPathCentroid = totalDistanceToSwimPathCentroid / i
            averageDistanceToOldPlatform = totalDistanceToOldPlatform / i
            averageDistanceToCenter = totalDistanceToCenterOfPool / i
            averageHeadingError = totalHeadingError / i

            missingDataFlag = 0
            if missingData > (i / 10):  # if we are missing more than 10% data, notify
                # print("Too much missing data, suggest throwing trial out (>10%). Missing ", missingData)
                show_error("Missing Data " + aFile)
                missingDataFlag = 1

            cellCounter = 0.0  # initialize our cell counter

            for k in range(0, 18):  # count how many cells we have visited
                for j in range(0, 18):
                    if Matrix[k][j] == 1:
                        cellCounter += 1.0

            # print distanceTotal/(i/25), avHeadingError
            percentTraversed = (
                                   cellCounter / (
                                   252.0 * scalingFactor)) * 100.0  # turn our count into a percentage over how many cells we can visit

            strategyType = ""
            # DIRECT SWIM
            if jsls <= jslsMaxVal and averageHeadingError <= headingMaxVal and isRuediger == False and useDirectSwimV:  # direct swim
                directSwimCount += 1.0
                strategyType = "Direct Swim"
            elif isRuediger == True and corridorAverage >= 0.98 and useDirectSwimV:
                directSwimCount += 1.0
                strategyType = "Direct Swim"
            # FOCAL SEARCH
            elif averageDistanceToSwimPathCentroid < (poolRadius * distanceToSwimMaxVal) and distanceAverage < (
                        distanceToPlatMaxVal * poolRadius) and useFocalSearchV:  # Focal Search
                focalSearchCount += 1.0
                strategyType = "Focal Search"
            # DIRECTED SEARCH
            elif corridorAverage >= corridorAverageMaxVal and jsls <= corridorjslsMaxVal and useDirectedSearchV:  # directed search
                directSearchCount += 1.0
                strategyType = "Directed Search"
            # spatial INDIRECT
            elif jsls < jslsIndirectMaxVal and useIndirectV:  # Near miss
                strategyType = "Spatial Indirect"
                spatialIndirectCount += 1.0
            # PERSEVERANCE
            elif averageDistanceToSwimPathCentroid < (distanceToSwimMaxVal * poolRadius) and averageDistanceToOldPlatform < (distanceToPlatMaxVal * poolRadius) and usePerseveranceV:
                perseveranceCount += 1.0
                print("Perseverance")
            # CHAINING
            elif float(
                            annulusCounter / i) > annulusCounterMaxVal and quadrantTotal >= quadrantTotalMaxVal and useChainingV:  # or 4 chaining
                chainingCount += 1.0
                strategyType = "Chaining"
            # SCANNING
            elif percentTraversedMinVal <= percentTraversed >= percentTraversedMaxVal and averageDistanceToCenter <= (
                distanceToCentreMaxVal * poolRadius) and useScanningV:  # scanning
                scanningCount += 1.0
                strategyType = "Scanning"
            # THIGMOTAXIS
            elif innerWallCounter >= innerWallMaxVal * i and outerWallCounter >= i * outerWallMaxVal and useThigmoV:  # thigmotaxis
                thigmotaxisCount += 1.0
                strategyType = "Thigmotaxis"
            # RANDOM SEARCH
            elif percentTraversed >= percentTraversedRandomMaxVal and useRandomV:  # random search
                randomCount += 1.0
                strategyType = "Random Search"
            # NOT RECOGNIZED
            else:  # cannot categorize
                strategyType = "Not Recognized"
                notRecognizedCount += 1.0
                if manualFlag:
                    self.plotPoints(arrayX, arrayY, float(poolDiamVar), float(poolCentreX), float(poolCentreY),
                                    float(platformX), float(platformY), float(scalingFactor),
                                    str(cAnimalID))  # ask user for answer
                    root.wait_window(self.top2)  # we wait until the user responds
                    strategyType = searchStrategyV  # update the strategyType to that of the user
                    try:  # try and kill the popup window
                        self.top2.destroy()
                    except:
                        pass

            totalTrialCount += 1.0

            n += 1
            # print(strategyType)
            writer.writerow((cDay, cTr, item.tid, item.name, strategyType, item.animalID, missingDataFlag,
                             aFile))  # , aFile  writing to csv file
            f.flush()

        else:  # called on directory of files
            logging.debug("Going through directory: " + str(excelFileDirectory))
            for aFile in self.find_files(excelFileDirectory, extensionType):  # for all the files we find
                i = 0.0
                try:
                    wb = open_workbook(aFile)
                except:
                    # print("Corrupted excel file", aFile)
                    logging.error("Could not open excel file: "+aFile)
                    try:
                        show_error("Corrupted Excel File "+aFile)
                    except:
                        logging.info("Couldn't update the GUI")
                    continue

                for sheet in wb.sheets():  # for all sheets in the workbook
                    arrayX = []
                    arrayY = []
                    number_of_rows = sheet.nrows
                    headerLines = int(sheet.cell(0, 1).value)  # gets number of header lines in the spreadsheet
                    numOfRows = sheet.nrows - headerLines
                    number_of_columns = sheet.ncols
                    fullTrial = []
                    rows = []
                    k = 0
                    cCondition = ""
                    cTreatment = ""
                    cDay = ""
                    cTemp = ""
                    cGen = ""
                    cAnimalID = ""
                    cTrName = ""
                    cTrID = ""
                    cTr = ""

                    for k in range(0, 39):  # GET CONDITION TREATMENT AND DAY VALUES
                        if str(sheet.cell(k, 0).value) == "Condition" or str(sheet.cell(k, 0).value) == "Restraint":
                            cCondition = str(sheet.cell(k, 1).value)
                        elif str(sheet.cell(k, 0).value) == "Treatment":
                            cTreatment = str(sheet.cell(k, 1).value)
                        elif str(sheet.cell(k, 0).value) == "Day":
                            cDay = str(sheet.cell(k, 1).value)
                            if dayFlag == False:
                                oldDay = cDay
                                dayFlag = True
                        elif str(sheet.cell(k, 0).value) == "Temperature":
                            cTemp = str(sheet.cell(k, 1).value)
                        elif str(sheet.cell(k, 0).value) == "Genotype":
                            cGen = str(sheet.cell(k, 1).value)
                        elif str(sheet.cell(k, 0).value) == "Animal ID":
                            cAnimalID = str(sheet.cell(k, 1).value)
                        elif str(sheet.cell(k, 0).value) == "Trial name":
                            cTrName = str(sheet.cell(k, 1).value)
                        elif str(sheet.cell(k, 0).value) == "Trial ID":
                            cTrID = str(sheet.cell(k, 1).value)
                        elif str(sheet.cell(k, 0).value) == "Trial":
                            cTr = str(sheet.cell(k, 1).value)


                    for row in range(headerLines, number_of_rows):  # for each row

                        values = []

                        for col in range(1, 4):  # for columns 1 through 4, get all the values
                            value = sheet.cell(row, col).value
                            try:
                                value = float(value)
                            except ValueError:
                                pass
                            finally:
                                values.append(value)

                        item = Trial(*values)
                        fullTrial.append(item)



                    if cDay != str(oldDay) and flag:  # this is what we use to output totals for each day in the CSV file
                        if (totalTrialCount - oldTotalCount) != 0:

                            writer.writerow(())
                            writer.writerow(())
                            writer.writerow(("Direct Swim", "Focal Search", "Directed Search", "Spatial Indirect", "Chaining",
                                             "Scanning", "Thigmotaxis", "Random Search", "Not Recognized", "Total Categorized",
                                             "Spatial Strategy Categorization", "Non-Spatial"))
                            writer.writerow((directSwimCount - oldDirectSwimCount, focalSearchCount - oldFocalSearchCount,
                                             directSearchCount - oldDirectSearchCount,
                                             spatialIndirectCount - oldspatialIndirectCount, chainingCount - oldChainingCount,
                                             scanningCount - oldScanningCount, thigmotaxisCount - oldThigmotaxisCount,
                                             randomCount - oldRandomCount, notRecognizedCount - oldNotRecognizedCount, round((((
                                                                                                                                   (
                                                                                                                                       totalTrialCount - oldTotalCount) - (
                                                                                                                                       notRecognizedCount - oldNotRecognizedCount)) / (
                                                                                                                                   totalTrialCount - oldTotalCount)) * 100),
                                                                                                                             2),
                                             directSwimCount - oldDirectSwimCount + directSearchCount - oldDirectSearchCount + focalSearchCount - oldFocalSearchCount + spatialIndirectCount - oldspatialIndirectCount,
                                             chainingCount - oldChainingCount + scanningCount - oldScanningCount + thigmotaxisCount - oldThigmotaxisCount + randomCount - oldRandomCount))
                            writer.writerow(())
                            oldDay = cDay
                            oldTotalCount = totalTrialCount
                            oldThigmotaxisCount = thigmotaxisCount
                            oldRandomCount = randomCount
                            oldScanningCount = scanningCount
                            oldChainingCount = chainingCount
                            oldDirectSearchCount = directSearchCount
                            oldFocalSearchCount = focalSearchCount
                            oldDirectSwimCount = directSwimCount
                            oldPerseveranceCount = perseveranceCount
                            oldspatialIndirectCount = spatialIndirectCount
                            oldNotRecognizedCount = notRecognizedCount
                            writer.writerow(())
                            f.flush()
                flag = True

                xSummed = 0.0
                ySummed = 0.0
                xAv = 0.0
                yAv = 0.0

                currentDistanceFromPlatform = 0.0
                distanceFromPlatformSummed = 0.0
                distanceAverage = 0.0
                aX = 0.0
                aY = 0.0

                missingData = 0

                distanceToCenterOfPool = 0.0
                totalDistanceToCenterOfPool = 0.0
                averageDistanceToCenter = 0.0

                innerWallCounter = 0.0
                outerWallCounter = 0.0
                annulusCounter = 0.0

                distanceToSwimPathCentroid = 0.0
                totalDistanceToSwimPathCentroid = 0.0
                averageDistanceToSwimPathCentroid = 0.0

                distanceToOldPlatform = 0.0
                totalDistanceToOldPlatform = 0.0
                averageDistanceToOldPlatform = 0.0

                jsls = 0.0

                startX = 0.0
                startY = 0.0

                areaCoverageGridSize = 18

                corridorCounter = 0.0
                quadrantOne = 0
                quadrantTwo = 0
                quadrantThree = 0
                quadrantFour = 0
                quadrantTotal = 0
                # </editor-fold>
                # initialize our cell matrix
                Matrix = [[0 for x in range(0, areaCoverageGridSize)] for y in range(0, areaCoverageGridSize)]
                # Analyze the data ----------------------------------------------------------------------------------------------

                for item in fullTrial:  # for each row in our sheet

                    if item.x == "-":  # throw out missing data
                        missingData += 1  # keep track of how much we throw out
                        continue
                    if item.y == "-":
                        missingData += 1
                        continue
                    if item.time < 1.0:
                        continue
                    if i == 0:
                        startX = item.x
                        startY = item.y
                    if item.time > (((number_of_rows - 39) * 0.04) - 1):
                        continue

                    arrayX.append(item.x)
                    arrayY.append(item.y)
                    # Swim Path centroid
                    i += 1.0
                    xSummed += float(item.x)
                    ySummed += float(item.y)
                    aX = float(item.x)
                    aY = float(item.y)
                    # Average Distance
                    currentDistanceFromPlatform = math.sqrt((platformX - aX) ** 2 + (platformY - aY) ** 2)
                    distanceFromPlatformSummed += currentDistanceFromPlatform
                    distanceToOldPlatform = math.sqrt((oldPlatformX - aX) ** 2 + (oldPlatformY - aY) ** 2)
                    totalDistanceToOldPlatform += distanceToOldPlatform

                    # in zones
                    poolCentreX, poolCentreY = poolCenter
                    distanceCenterToPlatform = math.sqrt((poolCentreX - platformX) ** 2 + (poolCentreY - platformY) ** 2)
                    annulusZoneInner = distanceCenterToPlatform - (chainingRadius / 2)
                    annulusZoneOuter = distanceCenterToPlatform + (chainingRadius / 2)
                    distanceToCenterOfPool = math.sqrt((poolCentreX - aX) ** 2 + (poolCentreY - aY) ** 2)
                    totalDistanceToCenterOfPool += distanceToCenterOfPool
                    distanceFromStartToPlatform = math.sqrt((platformX - startX) ** 2 + (platformY - startY) ** 2)

                    jsls += -(distanceFromStartToPlatform - distanceFromPlatformSummed) / 1000

                    if distanceToCenterOfPool > biggerWallZone:  # calculate if we are in zones
                        innerWallCounter += 1.0
                    if distanceToCenterOfPool > smallerWallZone:
                        outerWallCounter += 1.0
                    if (distanceToCenterOfPool >= annulusZoneInner) and (distanceToCenterOfPool <= annulusZoneOuter):
                        annulusCounter += 1

                    a, b = 0, 0
                    # grid creation
                    # x values
                    # <editor-fold desc="Grid">
                    if item.x >= -100.0 and item.x <= -90:
                        a = -9
                    elif item.x > -90 and item.x <= -80:
                        a = -8
                    elif item.x > -80 and item.x <= -70:
                        a = -7
                    elif item.x > -70 and item.x <= -60:
                        a = -6
                    elif item.x > -60 and item.x <= -50:
                        a = -5
                    elif item.x > -50 and item.x <= -40:
                        a = -4
                    elif item.x > -40 and item.x <= -30:
                        a = -3
                    elif item.x > -30 and item.x <= -20:
                        a = -2
                    elif item.x > -20 and item.x <= -10:
                        a = -1
                    elif item.x > -10 and item.x <= 0:
                        a = 0
                    elif item.x > 0 and item.x <= 10:
                        a = 1
                    elif item.x > 10 and item.x <= 20:
                        a = 2
                    elif item.x > 20 and item.x <= 30:
                        a = 3
                    elif item.x > 30 and item.x <= 40:
                        a = 4
                    elif item.x > 40 and item.x <= 50:
                        a = 5
                    elif item.x > 50 and item.x <= 60:
                        a = 6
                    elif item.x > 60 and item.x <= 70:
                        a = 7
                    elif item.x > 70 and item.x <= 80:
                        a = 8
                    elif item.x > 80 and item.x <= 90:
                        a = 9

                    # y value categorization
                    if item.y >= -100.0 and item.y <= -90:
                        b = -9
                    elif item.y > -90 and item.y <= -80:
                        b = -8
                    elif item.y > -80 and item.y <= -70:
                        b = -7
                    elif item.y > -70 and item.y <= -60:
                        b = -6
                    elif item.y > -60 and item.y <= -50:
                        b = -5
                    elif item.y > -50 and item.y <= -40:
                        b = -4
                    elif item.y > -40 and item.y <= -30:
                        b = -3
                    elif item.y > -30 and item.y <= -20:
                        b = -2
                    elif item.y > -20 and item.y <= -10:
                        b = -1
                    elif item.y > -10 and item.y <= 0:
                        b = 0
                    elif item.y > 0 and item.y <= 10:
                        b = 1
                    elif item.y > 10 and item.y <= 20:
                        b = 2
                    elif item.y > 20 and item.y <= 30:
                        b = 3
                    elif item.y > 30 and item.y <= 40:
                        b = 4
                    elif item.y > 40 and item.y <= 50:
                        b = 5
                    elif item.y > 50 and item.y <= 60:
                        b = 6
                    elif item.y > 60 and item.y <= 70:
                        b = 7
                    elif item.y > 70 and item.y <= 80:
                        b = 8
                    elif item.y > 80 and item.y <= 90:
                        b = 9
                    # </editor-fold>
                    Matrix[a][b] = 1  # set matrix cells to 1 if we have visited them
                    if (poolCentreX - aX) != 0:
                        centerArcTangent = math.degrees(math.atan((poolCentreY - aY) / (poolCentreX - aX)))

                    # print centerArcTangent
                    if item.x >= 0 and item.y >= 0:
                        quadrantOne = 1
                    elif item.x < 0 and item.y >= 0:
                        quadrantTwo = 1
                    elif item.x >= 0 and item.y < 0:
                        quadrantThree = 1
                    elif item.x < 0 and item.y < 0:
                        quadrantFour = 1

                quadrantTotal = quadrantOne + quadrantTwo + quadrantThree + quadrantFour
                # <editor-fold desc="Swim Path centroid">
                if i <= 0:  # make sure we don't divide by 0
                    i = 1

                xAv = xSummed / i  # get our average positions for the centroid
                yAv = ySummed / i
                swimPathCentroid = (xAv, yAv)

                aArcTangent = math.degrees(math.atan((platformY - startY) / (platformX - startX)))
                upperCorridor = aArcTangent + corridorWidth
                lowerCorridor = aArcTangent - corridorWidth
                corridorWidth = 0.0
                totalHeadingError = 0.0

                for item2 in fullTrial:  # go back through all values and calculate distance to the centroid
                    if item2.x == "-":
                        continue
                    if item2.y == "-":
                        continue
                    if item2.time < 1.0:
                        continue
                    if item2.time > (((number_of_rows - 39) * 0.04) - 1):
                        continue

                    distanceToSwimPathCentroid = math.sqrt((xAv - item2.x) ** 2 + (yAv - item2.y) ** 2)
                    totalDistanceToSwimPathCentroid += distanceToSwimPathCentroid

                    if (item2.x - startX) != 0 and (item2.x - oldItemX) != 0:
                        currentArcTangent = math.degrees(math.atan((item2.y - startY) / (item2.x - startX)))
                        corridorWidth = abs(aArcTangent - abs(math.degrees(math.atan((item2.y - oldItemY) / (item2.x - oldItemX)))))
                        if float(lowerCorridor) <= float(currentArcTangent) <= float(upperCorridor):
                            # print(lowerCorridor, currentArcTangent, upperCorridor)
                            corridorCounter += 1.0

                    oldItemX = item2.x
                    oldItemY = item2.y
                    if item2.time < (((number_of_rows - 39) * 0.04) - 1):
                        totalHeadingError += corridorWidth
                # </editor-fold>
                # <editor-fold desc="Take Averages">
                corridorAverage = corridorCounter / i
                distanceAverage = distanceFromPlatformSummed / i  # calculate our average distances to landmarks
                averageDistanceToSwimPathCentroid = totalDistanceToSwimPathCentroid / i
                averageDistanceToOldPlatform = totalDistanceToOldPlatform / i
                averageDistanceToCenter = totalDistanceToCenterOfPool / i
                averageHeadingError = totalHeadingError / i

                missingDataFlag = 0
                if missingData > (i / 10):  # if we are missing more than 10% data, notify
                    # print("Too much missing data, suggest throwing trial out (>10%). Missing ", missingData)
                    show_error("Missing Data " + aFile)
                    missingDataFlag = 1

                cellCounter = 0.0  # initialize our cell counter

                for k in range(0, 18):  # count how many cells we have visited
                    for j in range(0, 18):
                        if Matrix[k][j] == 1:
                            cellCounter += 1.0

                # print distanceTotal/(i/25), avHeadingError
                percentTraversed = (
                            cellCounter / (252.0 * scalingFactor)) * 100.0  # turn our count into a percentage over how many cells we can visit

                strategyType = ""
                # DIRECT SWIM
                if jsls <= jslsMaxVal and averageHeadingError <= headingMaxVal and isRuediger == False and useDirectSwimV:  # direct swim
                    directSwimCount += 1.0
                    strategyType = "Direct Swim"
                elif isRuediger == True and corridorAverage >= 0.98 and useDirectSwimV:
                    directSwimCount += 1.0
                    strategyType = "Direct Swim"
                # FOCAL SEARCH
                elif averageDistanceToSwimPathCentroid < (poolRadius * distanceToSwimMaxVal) and distanceAverage < (
                    distanceToPlatMaxVal * poolRadius) and useFocalSearchV:  # Focal Search
                    focalSearchCount += 1.0
                    strategyType = "Focal Search"
                # DIRECTED SEARCH
                elif corridorAverage >= corridorAverageMaxVal and jsls <= corridorjslsMaxVal and useDirectedSearchV:  # directed search
                    directSearchCount += 1.0
                    strategyType = "Directed Search"
                # spatial INDIRECT
                elif jsls < jslsIndirectMaxVal and useIndirectV:
                    strategyType = "Spatial Indirect"
                    spatialIndirectCount += 1.0
                #  PERSEVERANCE
                elif averageDistanceToSwimPathCentroid < (distanceToSwimMaxVal*poolRadius) and averageDistanceToOldPlatform < (distanceToPlatMaxVal*poolRadius) and usePerseveranceV:
                    perseveranceCount += 1.0
                    print("Perseverance")
                # CHAINING
                elif float(annulusCounter / i) > annulusCounterMaxVal and quadrantTotal >= quadrantTotalMaxVal and useChainingV:  # or 4 chaining
                    chainingCount += 1.0
                    strategyType = "Chaining"
                # SCANNING
                elif percentTraversedMinVal <= percentTraversed >= percentTraversedMaxVal and averageDistanceToCenter <= (distanceToCentreMaxVal * poolRadius) and useScanningV:  # scanning
                    scanningCount += 1.0
                    strategyType = "Scanning"
                # THIGMOTAXIS
                elif innerWallCounter >= innerWallMaxVal * i and outerWallCounter >= i * outerWallMaxVal and useThigmoV:  # thigmotaxis
                    thigmotaxisCount += 1.0
                    strategyType = "Thigmotaxis"
                # RANDOM SEARCH
                elif percentTraversed >= percentTraversedRandomMaxVal and useRandomV:  # random search
                    randomCount += 1.0
                    strategyType = "Random Search"
                # NOT RECOGNIZED
                else:  # cannot categorize
                    strategyType = "Not Recognized"
                    notRecognizedCount += 1.0
                    if manualFlag:
                        self.plotPoints(arrayX, arrayY, float(poolDiamVar), float(poolCentreX), float(poolCentreY), float(platformX), float(platformY), float(scalingFactor), str(cAnimalID))  # ask user for answer
                        root.wait_window(self.top2)  # we wait until the user responds
                        strategyType = searchStrategyV  # update the strategyType to that of the user
                        try:  # try and kill the popup window
                            self.top2.destroy()
                        except:
                            pass

                totalTrialCount += 1.0

                n += 1

                writer.writerow((cDay, cTr, cTrID, cTrName, strategyType, cAnimalID, missingDataFlag,
                             aFile))
                f.flush()
                logging.info("For " + str(aFile) + "... Day " + str(cDay) + " Trial " + str(cTr)+" ID " + str(cTrID) + " Trial Name " + str(cTrName) + " Strategy type " + str(strategyType) + " Animal ID " + str(cAnimalID) + " Missing Data 1/0? " + str(missingDataFlag))


            sys.stdout.write("\n")
            if (totalTrialCount - oldTotalCount) != 0:

                writer.writerow(())
                writer.writerow(("Direct Swim", "Focal Search", "Directed Search", "Spatial Indirect", "Chaining", "Scanning",
                                 "Thigmotaxis", "Random Search", "Not Recognized", "Total Categorized",
                                 "Spatial Strategy Categorization", "Non-Spatial"))
                writer.writerow((directSwimCount - oldDirectSwimCount, focalSearchCount - oldFocalSearchCount,
                                 directSearchCount - oldDirectSearchCount, spatialIndirectCount - oldspatialIndirectCount,
                                 chainingCount - oldChainingCount, scanningCount - oldScanningCount,
                                 thigmotaxisCount - oldThigmotaxisCount, randomCount - oldRandomCount,
                                 notRecognizedCount - oldNotRecognizedCount, round(((((totalTrialCount - oldTotalCount) - (
                    notRecognizedCount - oldNotRecognizedCount)) / (totalTrialCount - oldTotalCount)) * 100), 2),
                                 directSwimCount - oldDirectSwimCount + directSearchCount - oldDirectSearchCount + focalSearchCount - oldFocalSearchCount + spatialIndirectCount - oldspatialIndirectCount,
                                 chainingCount - oldChainingCount + scanningCount - oldScanningCount + thigmotaxisCount - oldThigmotaxisCount + randomCount - oldRandomCount))
                writer.writerow(())
                writer.writerow(("Direct Swim", "Focal Search", "Directed Search", "Spatial Indirect", "Chaining", "Scanning",
                                 "Thigmotaxis", "Random Search", "Not Recognized", "Total Categorized",
                                 "Spatial Strategy Categorization", "Non-Spatial"))
                writer.writerow((directSwimCount, focalSearchCount, directSearchCount, spatialIndirectCount, chainingCount,
                                 scanningCount, thigmotaxisCount, randomCount, notRecognizedCount,
                                 round((((totalTrialCount - notRecognizedCount) / totalTrialCount) * 100), 2),
                                 directSwimCount + directSearchCount + focalSearchCount + spatialIndirectCount,
                                 chainingCount + scanningCount + thigmotaxisCount + randomCount))
                f.flush()
                """print("Direct Swim: ", directSwimCount, "  Focal Search: ", focalSearchCount, "  Directed Search: ",
                      directSearchCount, "  spatial Indirect: ", spatialIndirectCount, "  Chaining: ", chainingCount,
                      "  Scanning: ", scanningCount)
                print("Thigmotaxis: ", thigmotaxisCount, "  Random Search: ", randomCount, "  Not Recognized: ",
                      notRecognizedCount)
                print("Total Categorized: ", (totalTrialCount - notRecognizedCount), "/", totalTrialCount, " ",
                      (((totalTrialCount - notRecognizedCount) / totalTrialCount) * 100), "%")
                print("spatial Strategy Categorization: ",
                      directSwimCount + directSearchCount + focalSearchCount + spatialIndirectCount, "  Non-spatial: ",
                      chainingCount + scanningCount + thigmotaxisCount + randomCount)"""

                logging.info("Final results: Direct Swim: "+ str(directSwimCount) + "  Focal Search: " + str(focalSearchCount)+ "  Directed Search: "+
                      str(directSearchCount) + "  spatial Indirect: "+ str(spatialIndirectCount) + "  Chaining: " + str(chainingCount) +
                      "  Scanning: " + str(scanningCount))
        theStatus.set('Updating CSV...')
        self.updateTasks()

        csvfilename = "results " + str(strftime("%Y_%m_%d %I_%M_%S_%p", localtime())) + ".csv"  # update the csv file name for the next run
        outputFileStringVar.set(csvfilename)
        csvDisplay(root)
        theStatus.set('')
        self.updateTasks()
        self.killBar()
        try:
            t1.join()
            t2.join()
        except:
            return

def main():
    b = mainClass(root)  # start the main class (main program)
    root.mainloop()  # loop so the gui stays

if __name__ == "__main__":  # main part of the program -- this is called at runtime
    main()
